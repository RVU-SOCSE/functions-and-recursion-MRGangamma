def fibonacci(n):
    a = 0
    b = 1

    for i in range(n):
        print(a,"\n")
        c=a+b
        a = b
        b = c

n = int(input("Enter how many numbers you want: "))
fibonacci(n)
