sentence = input("Enter a sentence: ")
count = 0

for word in sentence.split():
    count = count + 1

print("Number of words:", count)
